/*
    Module: TrafficConfig.hpp
    Author: LE MANH THANG
    Created: Dec 21th, 2021
*/


#ifndef TrafficConfig_hpp
#define TrafficConfig_hpp

#include <iostream>
#include "../../AiCore/AITypeData.hpp"

// #define ANDROID                                                                                                                                                                                                                                                                                                                                                                                                          


using namespace std;
using namespace cv;

namespace airuntime{
    namespace aiengine{


    }
}

#endif